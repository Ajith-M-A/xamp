    var config = {
        map: {
            '*': {
                'example-modal': 'Cloudways_M2Modal/js/example-modal'
            }
        }
    };